Title: A very simple Server/Client chat
Description: This small code will show you how a server/client chat application works using Winsock, it is very simply and i used blocking mode, this means in my program that the server can't response because he's receiving messages and the server only continue with receiving messages if a message has been send :-). Whatever this is excellent for beginners in the Winsock world.
!Important!: Link wsock32.lib and ws2_32.lib to your project! 

This file came from Planet-Source-Code.com...the home millions of lines of source code
You can view comments on this code/and or vote on it at: http://www.Planet-Source-Code.com/vb/scripts/ShowCode.asp?txtCodeId=9818&lngWId=3

The author may have retained certain copyrights to this code...please observe their request and the law by reviewing all copyright conditions at the above URL.
